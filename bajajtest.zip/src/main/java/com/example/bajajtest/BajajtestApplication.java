package com.example.bajajtest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BajajtestApplication {

	public static void main(String[] args) {
		SpringApplication.run(BajajtestApplication.class, args);
	}

}
